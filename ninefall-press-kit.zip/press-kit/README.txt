NINEFALL - PRESS KIT
====================
https://ninefall.app   ·   Updated 20 September 2026

THE GAME
Ninefall is a chain-reaction number puzzle. Every tile holds a number. Play one
from your hand onto a tile: the values add, the tile flips, and every
lower-numbered neighbour topples after it, domino-chaining across the board.
Past nine, numbers roll over, so 6 + 6 = 2. The goal is to flip the whole board,
ideally in one perfect Grand Cascade.

FACTS
  Title            Ninefall
  Developer        Thomas Sobstyl (solo developer)
  Platforms        iPhone, iPad. iOS 17 or later.
                   Android build complete, in closed testing on Google Play
  Released         20 August 2026
  Current version  1.3: free to start, the Autumn season, the board widget
  Price            Free to download
  Monetisation     One non-consumable in-app purchase, "Full game, forever",
                   $4.99 USD. Family Sharing on. No ads, no subscription,
                   no season pass, no currency, no second product.
  Free portion     Worlds 1 and 2 (24 levels), world 2's secret level, the
                   Daily Flip in full, the first ten One-Shot boards, unlimited
                   undo and the solver hint, both themes, Game Center, widgets,
                   and any board another player shares with you.
  The unlock opens Worlds 3 to 8 (72 more levels), the six other secret levels,
                   the whole One-Shot ladder, the Sandbox, and every world and
                   pack released later.
  Founders         Everyone who bought Ninefall while it was a paid app keeps
                   everything, automatically, and is marked a Founder in the
                   app with the original icon offered back. Never sold.
  Download size    3.3 MB
  Content          8 worlds, 96 levels, 7 secret levels, Daily Flip,
                   One-Shot mode, Sandbox
  Seasons          Autumn 2026: 15 dated boards built on the Leaf tile, one a
                   day from 1 to 15 October, free for everyone while the season
                   runs and part of the full game afterwards.
  Languages        English, 日本語, 简体中文, 繁體中文, 한국어,
                   Deutsch, Français, Español, Português (Brasil)
  Data collected   None. App Store privacy label reads "Data Not Collected".
  App Store        https://apps.apple.com/app/id6789261861
  Contact          contact@ninefall.app

WHAT MAKES IT DIFFERENT
  · Every level ships machine-verified: provably solvable, par exact, and its
    optional master goal reachable. The proof is stored with the level.
  · No lives, no timers, no energy. Unlimited undo and a solver-backed hint.
  · Free to start with exactly one purchase behind it, and no dark patterns
    around that purchase: no countdowns, no crossed-out prices, no second
    currency, no nagging. Locked worlds are simply marked as locked.
  · Written natively with no game engine, no cross-platform framework and no
    third-party code, which is why it fits in 3.3 MB.
  · The Daily Flip is generated on-device from the date, so everyone in the
    world gets the same board with no server and no account.
  · Since 1.3 the large Home Screen widget draws the day's board and the four
    numbers in hand, and the cleared board once it is solved. On iOS 27 it goes
    extra-large and fills the screen.

CONTENTS OF THIS KIT
  logo/         Cascade mark, wordmark and horizontal lockups (SVG and PNG).
                "-ink" is for light backgrounds, "-cream" for dark.
  icon/         App icon at 1024 px.
  screenshots/  Nine iPhone screenshots at 1320 × 2868.

LOGO USAGE
  · The cascade mark is always full colour. Please do not recolour it.
  · Keep clear space of at least the height of the wordmark's "N" on all sides.
  · Minimum sizes: wordmark 90 px wide, cascade mark 96 px, app icon 40 px.
  · The wordmark is two-tone: NINE in ink, FALL in coral (#C86450 on light,
    #E0846F on dark).

PALETTE
  Plum #6F303F   Coral #CE6A52   Butter #ECBB78   Accent #C86450
  Paper (Day) #F1E7D2   Paper (Night) #211A13   Ink #3E2F26

Review copies and offer codes are available on request: write to
contact@ninefall.app. Screenshots, cascade GIFs and the app preview video can be
supplied in other formats if you need them.
